package com.politecnicomalaga.fruitmonkey;

import com.badlogic.gdx.ApplicationAdapter;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.utils.Array;
import com.badlogic.gdx.utils.ScreenUtils;

public class GdxFruitMonkey extends ApplicationAdapter {
	SpriteBatch batch;
	Texture img;
	Texture fondo;
	ObjetoVolador fruta;
	ObjetoVolador macaco;
	Array<ObjetoVolador> frutas;
	PanelNumeros panel;
	float resultado;
	int segundos,puntos;

	public float posXrandom(){
		resultado= (float) Math.random()* Gdx.graphics.getWidth();
		return resultado;
	}

	public void MovClicar(){
		if (Gdx.input.justTouched()){
			float posRaton=Gdx.input.getX();
			if (posRaton<Gdx.graphics.getWidth()/3){
				//izquierda
				macaco.setVelX(-2);
			}

					//el x2 es para que sea mayor que 2 tercios, osea el tercio de la derecha
			else if (posRaton>2*Gdx.graphics.getWidth()/3){
				//derecha
				macaco.setVelX(2);
			}
			else {
				//centro
				macaco.setVelX(0);

			}
		}
	}

	@Override
	public void create () {
		fondo = new Texture("f1.jpg");
		batch = new SpriteBatch();
		macaco = new ObjetoVolador(Gdx.graphics.getWidth()/2,20,0,0,"gorilla.png");
		frutas= new Array<ObjetoVolador>();
		segundos=0;
		panel = new PanelNumeros(20,20,20);
		puntos=0;
		panel.setData(puntos);
	}

	@Override
	public void render () {
		MovClicar();
		segundos++;
				if (segundos==80){
					fruta= new ObjetoVolador(posXrandom(),Gdx.graphics.getHeight()-50,0,-1);
					frutas.add(fruta);
					segundos=0;
				}



		ScreenUtils.clear(1, 0, 0, 1);
		batch.begin();
		batch.draw(fondo,0,0,Gdx.graphics.getWidth(),Gdx.graphics.getHeight());
		macaco.moverse();
		macaco.pintarse(batch);
		panel.pintarse(batch);

		for (ObjetoVolador frutita: frutas){
			frutita.moverse();
			frutita.pintarse(batch);


			//Si el macaco colisiona con la fruta de esta pos del array, se borra.
			if (macaco.colisiona(frutita)){
				frutita.dispose();
				frutas.removeValue(frutita,true);
				puntos++;
				panel.setData(puntos);
			}

		}

		batch.end();
	}


	
	@Override
	public void dispose () {
		batch.dispose();
		img.dispose();
	}
}
