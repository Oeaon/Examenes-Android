package com.politecnicomalaga.madmaxroad;

import com.badlogic.gdx.ApplicationAdapter;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.utils.Array;
import com.badlogic.gdx.utils.ScreenUtils;

public class GdxMadMaxRoad extends ApplicationAdapter {
	SpriteBatch batch;
	Texture img;
	ObjetoVolador jugador;
	Array<ObjetoVolador> enemigos;
	Array<ObjetoVolador> cochesRotos;
	Fondo fondo;
	protected  int widht, height;
	PanelNumeros panelillo;

	String[] Modeloscoches={"warcar1.png", "warcar2.png", "warcar3.png"};
	String ModeloCocheRoto= "broken.png";
	String Modelojugador= "interceptor.png";
	String ModeloFondo= "road.png";

	SpriteBatch sprite;

	public void MovClicar(){
		if (Gdx.input.justTouched()){
			float posRaton=Gdx.input.getY();
			if (posRaton<Gdx.graphics.getHeight()/2){
				//izquierda
				jugador.setVelY(-3);
			}

			//el x2 es para que sea mayor que 2 tercios, osea el tercio de la derecha
			else {
				//derecha
				jugador.setVelY(3);
			}

		}
	}

	@Override
	public void create () {
		batch = new SpriteBatch();
		widht= Gdx.graphics.getWidth();
		height= Gdx.graphics.getHeight();
		fondo= new Fondo(ModeloFondo,5,0,0,800,widht,height);
		jugador= new ObjetoVolador(50,height/2-32,0,0, new Texture(Modelojugador));
		panelillo = new PanelNumeros(50,50,50);
		enemigos = new Array<ObjetoVolador>();
		cochesRotos = new Array<ObjetoVolador>();
		panelillo.setData(3);
	}

	@Override
	public void render () {
		ScreenUtils.clear(1, 0, 0, 1);

		fondo.moverse();

		if (Math.random()>0.98){
			int posY = (int) (Math.random()*(height-64)+32);

			ObjetoVolador OtroCocheRoto = new ObjetoVolador(widht+50,posY,-5f,0, new Texture(ModeloCocheRoto));
			cochesRotos.add(OtroCocheRoto);
		}
		if (Math.random()>0.98){
			int cocheMalo = (int) (Math.random()*2)+1;
			int posY= (int) (Math.random()*(height-64)+32);
			ObjetoVolador OtroCocheMalo = new ObjetoVolador(widht+50,posY,-2.5f,0, new Texture(Modeloscoches[cocheMalo]));
			enemigos.add(OtroCocheMalo);
		}
		//MOVIMIENTO JUGADOR
		MovClicar();
		jugador.moverse();

		//MOVIMIENTOS ENEMIGOS
		for (ObjetoVolador roto: cochesRotos) {
			roto.moverse();
		}

		for (ObjetoVolador malvado: enemigos) {
			malvado.moverse();
		}

		for(int i =0; i<enemigos.size;i++){
			if (enemigos.get(i).colisiona(jugador)){
				enemigos.removeIndex(i);
				panelillo.disminuye(1);
				i--;
			}
		}

		for(int i =0; i<cochesRotos.size;i++){
			if (cochesRotos.get(i).colisiona(jugador)){
				cochesRotos.removeIndex(i);
				panelillo.disminuye(1);
				i--;
			}
		}

		if (panelillo.iValorAlmacenado==0){
			for(ObjetoVolador malvados : enemigos){
				malvados.setVelX(0);
			}
			for (ObjetoVolador cascados : cochesRotos){
				cascados.setVelX(0);
			}
			jugador.setVelX(0);
			fondo.setVelX(0);
			dispose();
		}

		//PINTADA
		batch.begin();
		fondo.pintarse(batch);
		panelillo.pintarse(batch);
		jugador.pintarse(batch);
		for(ObjetoVolador malvados : enemigos){
			malvados.pintarse(batch);
		}
		for (ObjetoVolador cascados : cochesRotos){
			cascados.pintarse(batch);
		}

		batch.end();


		//Salida de la pantalla
		if (jugador.getPosY()>=height*0.90){
			jugador.setVelY(0);
		}
		if (jugador.getPosY()<=height*0.001){
			jugador.setVelY(0);
		}
	}


	
	@Override
	public void dispose () {
		batch.dispose();
		img.dispose();
		jugador.dispose();
		fondo.dispose();

		for(ObjetoVolador malvados : enemigos){
			malvados.dispose();
		}
		for (ObjetoVolador cascados : cochesRotos){
			cascados.dispose();
		}
	}
}
