package com.politecnicomalaga.madmaxroad;

import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureRegion;

public class Fondo {
    private Texture imgBackgroud;
    private int velX, velY,posX,posY,ScreenWidth,ScreenHeight,width,height;


    public Fondo(String modeloImg, int velX, int velY, int posX, int posY, int screenWidth, int screenHeight) {

        this.imgBackgroud = new Texture(modeloImg);
        this.velX = velX;
        this.velY = velY;
        this.posX = posX;
        this.posY = posY;
        ScreenWidth = screenWidth;
        ScreenHeight = screenHeight;
        this.width = imgBackgroud.getWidth();
        this.height = imgBackgroud.getHeight();
    }

    public void moverse(){
        posX= posX+velX;
        posY=posY+velY;

        if (posX+ScreenWidth>= width && velX>0){
            posX=posX+ScreenWidth -width;
        }
        if (posX<=0 && velX<0){
            posX= width - ScreenWidth;
        }
        if (posY+ScreenHeight>= height && velY>0){
            posY=posY+ScreenHeight-height;
        }
        if (posY<=0 && velY<0){
            posY= height -ScreenHeight;
        }
    }

    public void pintarse(SpriteBatch Sb){
        TextureRegion screen;
        screen = new TextureRegion(imgBackgroud, posX,posY,ScreenWidth,ScreenHeight);

        Sb.draw(screen,0,0);
    }

    public Texture getImgBackgroud() {
        return imgBackgroud;
    }

    //GETTERS
    public int getVelX() {
        return velX;
    }

    public int getVelY() {
        return velY;
    }

    public int getPosX() {
        return posX;
    }

    public int getPosY() {
        return posY;
    }

    public int getScreenWidth() {
        return ScreenWidth;
    }

    public int getScreenHeight() {
        return ScreenHeight;
    }

    public int getWidth() {
        return width;
    }

    public int getHeight() {
        return height;
    }

  //  SETTERS
    public void setImgBackgroud(Texture imgBackgroud) {
        this.imgBackgroud = imgBackgroud;
    }

    public void setVelX(int velX) {
        this.velX = velX;
    }

    public void setVelY(int velY) {
        this.velY = velY;
    }

    public void setPosX(int posX) {
        this.posX = posX;
    }

    public void setPosY(int posY) {
        this.posY = posY;
    }

    public void setScreenWidth(int screenWidth) {
        ScreenWidth = screenWidth;
    }

    public void setScreenHeight(int screenHeight) {
        ScreenHeight = screenHeight;
    }

    public void setWidth(int width) {
        this.width = width;
    }

    public void setHeight(int height) {
        this.height = height;
    }

    public void dispose(){
        imgBackgroud.dispose();
    }
}
